// server.js
import express from "express";
import multer from "multer";
import * as XLSX from "xlsx";
import fetch from "node-fetch";
import JSZip from "jszip";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import dotenv from "dotenv";
import cors from "cors";

dotenv.config();
const app = express();
const upload = multer({ storage: multer.memoryStorage() });
app.use(cors());

const s3 = new S3Client({
  region: "us-east-1",
  endpoint: "https://moribr.nyc3.digitaloceanspaces.com",
  credentials: {
    accessKeyId: process.env.ACCESS_KEY,
    secretAccessKey: process.env.SECRET_KEY,
  },
});

app.post("/api/export-images", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Nenhum arquivo enviado" });

    const zip = new JSZip();
    const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    const erros = [];

    let progresso = 0;
    const total = rows.length;

    for (const row of rows) {
      const ref = row["REF"] || row[Object.keys(row)[0]];
      const imageUrl = row["ImageURL"] || row[Object.keys(row).find(key => key.toLowerCase().includes("image"))];

      if (!ref || !imageUrl) continue;

      try {
        const response = await fetch(imageUrl);
        if (!response.ok) throw new Error("Erro ao baixar");

        const buffer = await response.buffer();
        zip.file(`${ref}.jpg`, buffer);

        progresso++;
        console.log(`[${progresso}/${total}] Baixado: ${ref}`);
      } catch (e) {
        erros.push(ref);
        console.warn(`Erro ao baixar imagem: ${ref}`);
      }
    }

    const zipBuffer = await zip.generateAsync({ type: "nodebuffer" });

    const fileName = `imagens_${Date.now()}.zip`;

    await s3.send(new PutObjectCommand({
      Bucket: "moribr",
      Key: fileName,
      Body: zipBuffer,
      ACL: "public-read",
      ContentType: "application/zip",
    }));

    const url = `https://moribr.nyc3.cdn.digitaloceanspaces.com/${fileName}`;
    res.json({ message: "Exportação finalizada", downloadUrl: url, erros });
  } catch (err) {
    console.error("Erro ao exportar imagens:", err);
    res.status(500).json({ error: "Erro interno no servidor" });
  }
});

app.listen(3001, () => {
  console.log("🚀 Servidor backend rodando em http://localhost:3001");
});
